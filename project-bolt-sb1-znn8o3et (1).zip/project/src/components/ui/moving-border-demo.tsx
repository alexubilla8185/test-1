"use client";
import React from "react";
import { Button } from "@/components/ui/moving-border";

interface MovingBorderDemoProps {
  text?: string;
  variant?: 'default' | 'white';
  className?: string;
  onClick?: () => void;
}

export function MovingBorderDemo({ 
  text = "Get Started", 
  variant = 'default',
  className = "",
  onClick
}: MovingBorderDemoProps) {
  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      // Default behavior: scroll to contact section
      const contactSection = document.getElementById('contact');
      if (contactSection) {
        contactSection.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const baseClasses = variant === 'white' 
    ? "bg-white text-blue-600 border-blue-500 hover:bg-gray-50" 
    : "bg-slate-900 text-white border-blue-500 hover:bg-slate-800";

  return (
    <div className="flex items-center justify-center">
      <Button
        borderRadius="1.75rem"
        className={`${baseClasses} ${className}`}
        containerClassName="w-auto h-14 px-8"
        onClick={handleClick}
        borderClassName="bg-[radial-gradient(#3b82f6_40%,transparent_60%)]"
      >
        {text}
      </Button>
    </div>
  );
}