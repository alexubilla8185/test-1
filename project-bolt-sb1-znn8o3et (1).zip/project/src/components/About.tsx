import React from 'react';
import { Users, Award, Target, Lightbulb, Github, Linkedin, Twitter } from 'lucide-react';
import { motion } from 'framer-motion';
import { MovingBorderDemo } from './ui/moving-border-demo';

const About = () => {
  const values = [
    {
      icon: Target,
      title: 'Mission-Driven',
      description: 'We are committed to delivering exceptional technology solutions that drive real business results.'
    },
    {
      icon: Lightbulb,
      title: 'Innovation First',
      description: 'We stay ahead of technology trends to provide cutting-edge solutions for our clients.'
    },
    {
      icon: Users,
      title: 'Client-Focused',
      description: 'Your success is our success. We build lasting partnerships through trust and excellence.'
    },
    {
      icon: Award,
      title: 'Quality Assured',
      description: 'We maintain the highest standards in everything we do, from code quality to customer service.'
    }
  ];

  const stats = [
    { number: '25+', label: 'Years Experience' },
    { number: '100+', label: 'Projects Delivered' },
    { number: '50+', label: 'Happy Clients' },
    { number: '24/7', label: 'Support Available' }
  ];

  const teamMembers = [
    {
      name: 'Sarah Chen',
      title: 'Lead DevOps Engineer',
      bio: 'Sarah specializes in cloud infrastructure and automation with over 8 years of experience. She leads our DevOps initiatives and ensures seamless deployment pipelines for all client projects.',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      social: {
        linkedin: '#',
        github: '#',
        twitter: '#'
      }
    },
    {
      name: 'Marcus Rodriguez',
      title: 'Principal Cloud Architect',
      bio: 'Marcus designs scalable cloud solutions and has architected systems for Fortune 500 companies. His expertise in AWS and Azure helps clients achieve optimal performance and cost efficiency.',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      social: {
        linkedin: '#',
        github: '#',
        twitter: '#'
      }
    },
    {
      name: 'Emily Thompson',
      title: 'Senior Full-Stack Developer',
      bio: 'Emily brings 10+ years of full-stack development experience, specializing in React, Node.js, and modern web technologies. She leads our custom software development projects.',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      social: {
        linkedin: '#',
        github: '#',
        twitter: '#'
      }
    },
    {
      name: 'David Kim',
      title: 'Cybersecurity Specialist',
      bio: 'David ensures our clients\' digital assets are protected with comprehensive security strategies. His expertise includes penetration testing, compliance, and security architecture design.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      social: {
        linkedin: '#',
        github: '#',
        twitter: '#'
      }
    },
    {
      name: 'Lisa Wang',
      title: 'UX/UI Design Lead',
      bio: 'Lisa creates intuitive and beautiful user experiences that drive engagement and conversion. Her design philosophy focuses on user-centered design and accessibility best practices.',
      image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      social: {
        linkedin: '#',
        github: '#',
        twitter: '#'
      }
    },
    {
      name: 'James Wilson',
      title: 'Data Analytics Engineer',
      bio: 'James transforms complex data into actionable insights using machine learning and advanced analytics. He helps clients make data-driven decisions that accelerate business growth.',
      image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
      social: {
        linkedin: '#',
        github: '#',
        twitter: '#'
      }
    }
  ];

  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            About <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">TEKGUYZ</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We are a team of passionate technologists dedicated to helping businesses thrive in the digital age.
          </p>
        </motion.div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              Transforming Ideas into Digital Reality
            </h3>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Founded with a vision to bridge the gap between technology and business success, 
              TEKGUYZ has grown into a trusted partner for companies seeking digital transformation. 
              Our team combines deep technical expertise with business acumen to deliver solutions 
              that not only work but drive measurable results.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              From startups to enterprise organizations, we've helped hundreds of clients navigate 
              the complexities of modern technology, ensuring they stay competitive in an 
              ever-evolving digital landscape.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center p-4 bg-gray-50 rounded-xl"
                >
                  <div className="text-3xl font-bold text-blue-600 mb-2">{stat.number}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right Image */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
                alt="Team collaboration"
                className="w-full h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-600/20 to-transparent"></div>
            </div>
            
            {/* Floating elements */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="absolute -top-6 -right-6 bg-white p-4 rounded-xl shadow-lg"
            >
              <div className="text-2xl font-bold text-blue-600">99%</div>
              <div className="text-sm text-gray-600">Client Satisfaction</div>
            </motion.div>
          </motion.div>
        </div>

        {/* Values */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">Our Core Values</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center p-6 rounded-xl hover:bg-gray-50 transition-colors duration-300"
              >
                <div className="bg-gradient-to-r from-blue-500 to-purple-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <value.icon className="h-8 w-8 text-white" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-3">{value.title}</h4>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Team Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-4">
              Meet Our <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Expert Team</span>
            </h3>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our diverse team of developers, designers, and strategists brings together decades 
              of experience across various industries and technologies.
            </p>
          </div>

          {/* Team Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 text-center"
              >
                {/* Photo */}
                <div className="relative mb-6">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-32 h-32 rounded-full mx-auto object-cover shadow-lg"
                  />
                  <div className="absolute inset-0 w-32 h-32 rounded-full mx-auto bg-gradient-to-t from-blue-600/20 to-transparent"></div>
                </div>

                {/* Info */}
                <h4 className="text-xl font-bold text-gray-900 mb-2">{member.name}</h4>
                <p className="text-blue-600 font-medium mb-4">{member.title}</p>
                <p className="text-gray-600 text-sm leading-relaxed mb-6">{member.bio}</p>

                {/* Social Links */}
                <div className="flex justify-center space-x-4">
                  <a
                    href={member.social.linkedin}
                    className="p-2 bg-gray-100 rounded-lg hover:bg-blue-100 transition-colors duration-200"
                  >
                    <Linkedin className="h-4 w-4 text-gray-600 hover:text-blue-600" />
                  </a>
                  <a
                    href={member.social.github}
                    className="p-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors duration-200"
                  >
                    <Github className="h-4 w-4 text-gray-600" />
                  </a>
                  <a
                    href={member.social.twitter}
                    className="p-2 bg-gray-100 rounded-lg hover:bg-blue-100 transition-colors duration-200"
                  >
                    <Twitter className="h-4 w-4 text-gray-600 hover:text-blue-600" />
                  </a>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Team CTA */}
          <div className="text-center">
            <div className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-2xl p-12">
              <h4 className="text-3xl font-bold text-gray-900 mb-4">Want to Join Our Team?</h4>
              <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                We're always looking for talented individuals who share our passion for technology 
                and innovation. Explore career opportunities with TEKGUYZ.
              </p>
              <div className="flex justify-center">
                <MovingBorderDemo text="View Open Positions" />
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;