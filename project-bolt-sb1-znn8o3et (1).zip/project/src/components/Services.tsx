import React from 'react';
import { Monitor, Smartphone, Globe, Shield, Cloud, Code, Database, Zap, Users, FileText, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import { MovingBorderDemo } from './ui/moving-border-demo';

const Services = () => {
  const services = [
    {
      icon: Users,
      title: 'Tech Consulting',
      description: 'We provide strategic guidance to align your technology with your business goals. Our experts help you navigate complex challenges, from cloud adoption and infrastructure optimization to implementing a full-scale DevOps transformation. We create a clear roadmap for innovation, scalability, and long-term success.',
      ctaText: 'Plan Your Strategy'
    },
    {
      icon: Code,
      title: 'Custom Software Development',
      description: 'From concept to deployment, we build robust, scalable, and secure software solutions tailored to your specific needs. Our agile development process and expertise in CI/CD pipelines ensure we deliver high-quality code efficiently, providing you with a competitive edge in the market.',
      ctaText: 'Build Your Solution'
    },
    {
      icon: Shield,
      title: 'QA and Testing',
      description: 'Ensure your applications are reliable, performant, and secure with our comprehensive QA and testing services. We specialize in automated testing, performance analysis, and security audits, integrating quality assurance directly into the development lifecycle to reduce bugs and accelerate release cycles.',
      ctaText: 'Ensure Quality'
    },
    {
      icon: FileText,
      title: 'Technical Writing',
      description: 'Clear, concise documentation is crucial for success. We create professional technical documentation for your products, APIs, and internal processes. Our services empower your development teams and end-users with the information they need to succeed.',
      ctaText: 'Improve Your Docs'
    },
    {
      icon: Globe,
      title: 'Web Design & Management',
      description: 'We design, build, and manage high-performance websites that are both visually appealing and technically sound. Our focus is on creating secure, fast, and SEO-friendly web experiences that are easy to manage and scale as your business grows.',
      ctaText: 'Launch Your Website'
    },
    {
      icon: Settings,
      title: 'Domain & DNS Management',
      description: 'Build your online presence on a foundation of reliability and security. We manage your domain portfolio and configure your DNS for maximum uptime, performance, and protection against threats, ensuring your services are always available to your customers.',
      ctaText: 'Secure Your Domain'
    }
  ];

  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Our <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive technology solutions designed to accelerate your business growth and digital transformation journey.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 flex flex-col h-full"
            >
              {/* Icon */}
              <div className="bg-gradient-to-r from-blue-500 to-purple-500 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                <service.icon className="h-8 w-8 text-white" />
              </div>

              {/* Content */}
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
              <p className="text-gray-600 mb-8 leading-relaxed flex-grow">{service.description}</p>

              {/* CTA with Moving Border */}
              <div className="mt-auto">
                <MovingBorderDemo text={service.ctaText} />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-white">
            <h3 className="text-3xl font-bold mb-4">Ready to Transform Your Business?</h3>
            <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
              Let's discuss how our services can help you achieve your goals and drive innovation in your organization.
            </p>
            <div className="flex justify-center">
              <MovingBorderDemo text="Schedule a Consultation" variant="white" />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;